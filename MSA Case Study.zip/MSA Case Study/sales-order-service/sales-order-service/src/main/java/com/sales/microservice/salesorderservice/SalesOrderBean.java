package com.sales.microservice.salesorderservice;

import java.util.List;

public class SalesOrderBean {
	
	private String orderDesc;
	private String orderDate;
	private String customerEmailId;
	private List<String> itemsList;
	public String getOrderDesc() {
		return orderDesc;
	}
	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getCustomerEmailId() {
		return customerEmailId;
	}
	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	public List<String> getItemsList() {
		return itemsList;
	}
	public void setItemsList(List<String> itemsList) {
		this.itemsList = itemsList;
	}
	
	

}
