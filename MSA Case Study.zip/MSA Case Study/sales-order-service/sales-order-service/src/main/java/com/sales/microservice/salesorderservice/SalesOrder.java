package com.sales.microservice.salesorderservice;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class SalesOrder {
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private Long id;
	@Column(name="date")
	private String date;
	@Column(name="email_id")
	private String email;
	@Column(name="description")
	private String description;
	@Column(name="price")
	private String price;
/*	@OneToMany(targetEntity=OrderLineItem.class,mappedBy="order",
			cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<OrderLineItem> orderLineItem;
	*/
	public SalesOrder() {
		
	}
	public SalesOrder(Long id, String date, String email, String description, String price) {
		super();
		this.id = id;
		this.date = date;
		this.email = email;
		this.description = description;
		this.price = price;
		//this.orderLineItem= orderLineItem;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	/*public List<OrderLineItem> getOrderLineItem() {
		return orderLineItem;
	}
	public void setOrderLineItem(List<OrderLineItem> orderLineItem) {
		this.orderLineItem = orderLineItem;
	}*/

	
	
}
