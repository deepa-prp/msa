package com.sales.microservice.salesorderservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class OrderLineItem {
	
	@Id
	@Column(name="id")
	private Long id;
	@Column(name="item_name")
	private String itemName;
	@Column(name="quantity")
	private String quantity;
	/*@ManyToOne
	@JoinColumn(name="order_id")
	private SalesOrder order;*/
	
	public OrderLineItem() {
		
	}
	
	public OrderLineItem(Long id, String itemName, String quantity) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.quantity = quantity;
		//this.order = order;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
/*
	public SalesOrder getOrder() {
		return order;
	}

	public void setOrder(SalesOrder order) {
		this.order = order;
	}*/

	
	
}
