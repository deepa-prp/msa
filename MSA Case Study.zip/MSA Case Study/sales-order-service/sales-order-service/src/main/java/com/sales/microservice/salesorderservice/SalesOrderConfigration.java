package com.sales.microservice.salesorderservice;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix="sales-order-service")
@Component
public class SalesOrderConfigration {
	
	private String entryLogLabel;
	
	private Long defaultOrderValue;

	public String getEntryLogLabel() {
		return entryLogLabel;
	}

	public void setEntryLogLabel(String entryLogLabel) {
		this.entryLogLabel = entryLogLabel;
	}

	public Long getDefaultOrderValue() {
		return defaultOrderValue;
	}

	public void setDefaultOrderValue(Long defaultOrderValue) {
		this.defaultOrderValue = defaultOrderValue;
	}
	
	

}
