package com.sales.microservice.salesorderservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@EnableHystrix
public class SalesOrderService {
	
	@Autowired
	SalesOrderRepository salesOrderRepository;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	ItemService itemService;
	
	@Autowired
	SalesOrderConfigration salesOrderConfigration;
	
	private static final Logger log = LoggerFactory.getLogger(SalesOrderService.class);
	
	@PostMapping("api/service3/orders")
	public Long createNewOrder(@RequestBody SalesOrderBean SalesOrderBean) {
		log.info( salesOrderConfigration.getEntryLogLabel() + SalesOrderBean.getOrderDesc());
		
		//ResponseEntity<SalesOrder> forEntity = new RestTemplate().getForEntity("http://localhost:8180/api/service1/customers/{email}",SalesOrder.class,SalesOrderBean.getCustomerEmailId());
		//SalesOrder salesOrder = forEntity.getBody();
		try
		{
		SalesOrder salesOrder= customerService.getCustomerUsingEmail(SalesOrderBean.getCustomerEmailId());
		if(null != salesOrder 
				&& null != salesOrder.getEmail()) {
			//ResponseEntity<OrderLineItem> forEntity1 = new RestTemplate().getForEntity("http://localhost:8280/api/service2/items/biscut",OrderLineItem.class);
			OrderLineItem orderLineItem = itemService.getItemsByName("biscut");
			if(null != orderLineItem
					&& null != orderLineItem.getItemName()) {
				log.info("inside the sales order service createNewOrder method" + orderLineItem.getItemName());
				SalesOrder sales = new SalesOrder();
				sales.setDate(SalesOrderBean.getOrderDate());
				sales.setDescription(SalesOrderBean.getOrderDesc());
				sales.setPrice("50");
				sales.setEmail(SalesOrderBean.getCustomerEmailId());
				salesOrderRepository.save(sales);
				return new Long(3);
			}
		}
		log.info("inside the sales order service createNewOrder method" + salesOrder.getEmail());
		}
		catch(Exception exception)
		{
			throw new RuntimeException("Sales Service Issue");
		}
		//throw new RuntimeException("the validation failed");
		return new Long(0);
	}
	
	@GetMapping("api/service3/orders/{orderId}")
	@HystrixCommand(fallbackMethod="fallBackSalesOrderDetails")
	public SalesOrder getOrderById(@PathVariable Long orderId) {
		log.info("inside the sales order service getOrderById method");
		
			SalesOrder salesOrder = salesOrderRepository.findById(orderId);
			if(null != salesOrder)
				return salesOrder;
			else
				throw new RuntimeException("Sales Service Issue in order request");	
	}
	
	public SalesOrder fallBackSalesOrderDetails(Long orderId)
	{
		return new SalesOrder(new Long(5),"7/30/2019","test@dummy.com","Exception","100");
	}
	public Long fallBackSalesMethod() {
		return salesOrderConfigration.getDefaultOrderValue();
	}
	

}
