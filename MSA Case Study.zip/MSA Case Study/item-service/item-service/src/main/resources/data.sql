insert into Item(id,name,description,price) values('1','toy','Test1','21');
insert into Item(id,name,description,price) values('2','biscut','Test2','41');
insert into Item(id,name,description,price) values('3','gold','Test2','26');
insert into Item(id,name,description,price) values('4','diamond','Test3','67');