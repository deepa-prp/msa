package com.sales.microservice.itemservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
	
	@Id
	@Column(name="id")
	private Long id;
	@Column(name="name")
	private String itemName;
	@Column(name="description")
	private String description;
	@Column(name="price")
	private String price;

	public Item() {
		
	}
	public Item(Long id, String itemName, String description, String price) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.description = description;
		this.price = price;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	

}
