insert into Customer(email_id,first_name,last_name) values('deepa','Deepa','Palaniswami');
insert into Customer(email_id,first_name,last_name) values('devi','devi','priya');
insert into Customer(email_id,first_name,last_name) values('yamini','yamini','ashok');
insert into Customer(email_id,first_name,last_name) values('vetri','vetri','vel');