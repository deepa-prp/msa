package com.sales.microservices.customerservice;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerService {
	
	private static final Logger log = LoggerFactory.getLogger(CustomerService.class);
	
	@Autowired
	CustomerRepository customerRepository;
	
	@GetMapping("api/service1/customers")
	public List<Customer> getCustomer() {
		log.info("inside the customer service getCustomer method");
		return customerRepository.findAll();
		//return new Customer("abc@gmail.com","abc","last");
	}
	
	@GetMapping("api/service1/customers/{email}")
	public Customer getCustomerUsingEmail(@PathVariable String email) {
		log.info("inside the customer service getCustomerUsingEmail method" + email);
		return customerRepository.findByEmail(email);
		//return new Customer(email,"abc","last");
	}

}
